#pragma once
#ifndef GWEN_CONTROLS_DIALOGS_QUERY_H
#define GWEN_CONTROLS_DIALOGS_QUERY_H

#include "Gwen/Gwen.h"

namespace Gwen
{
	namespace Dialogs
	{
		//TODO. YesNo, Ok etc
	}
}
#endif
